package com.example.coincap.ui.ratestab.rates

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coincap.data.model.ratetab.rates.RatesModel
import com.example.coincap.databinding.FragmentRatesBinding
import com.example.coincap.ui.markets.MarketViewModel


class RatesFragment : Fragment() {

    private lateinit var viewModel: RatesViewModel
    private var _binding: FragmentRatesBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        viewModel =
            ViewModelProvider(this)[RatesViewModel::class.java]
        _binding = FragmentRatesBinding.inflate(inflater, container, false)

        viewModel.rate.observe(viewLifecycleOwner) {
            it?.let {
                setupUI(it)
            }
        }

        viewModel.getRates()

        return binding.root

    }

    fun setupUI(rates: RatesModel) {
        binding.rvRates.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = rates.data?.let { RatesAdapter(it) }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
